fun main() {
    testaAutenticacao()
}