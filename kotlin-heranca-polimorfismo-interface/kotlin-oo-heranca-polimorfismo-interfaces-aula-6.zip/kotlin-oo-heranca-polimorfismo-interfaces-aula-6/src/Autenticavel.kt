interface Autenticavel {

    fun autentica(senha: Int): Boolean

}